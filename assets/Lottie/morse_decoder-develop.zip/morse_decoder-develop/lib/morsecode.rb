require_relative 'morsecode/version'

module Morsecode
  class Error < StandardError; end
  # Your code goes here...
end
