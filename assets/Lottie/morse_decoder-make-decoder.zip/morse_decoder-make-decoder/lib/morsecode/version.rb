module Morsecode
  VERSION = '0.1.0'.freeze
end
